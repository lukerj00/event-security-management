import { events } from './App';

const eventsJson = JSON.stringify(events, null, 2);
console.log(eventsJson);